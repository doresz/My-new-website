public abstract class Zenesz {
    private String nev;
    private int azonosito;
    private int szereplesekSzama;

    public Zenesz(){

    }
    public Zenesz(String nev,int azonosito){
        this.nev = nev;
        this.azonosito = azonosito;
    }
    public String toString(){
        return "Zenész : név = "+nev+" azonosító = "+azonosito;
    }
    public int szerepel(){
        return szereplesekSzama++;
    }
    public abstract int fizetes(int penz);

    public String getNev() {
        return nev;
    }

    public void setNev(String nev) {
        this.nev = nev;
    }

    public int getAzonosito()
    {
        return azonosito;
    }

    public void setAzonosito(int azonosito) {
        this.azonosito = azonosito;
    }

    public int getSzereplesekSzama() {
        return szereplesekSzama;
    }

    public void setSzereplesekSzama(int szereplesekSzama) {
        this.szereplesekSzama = szereplesekSzama;
    }
}
