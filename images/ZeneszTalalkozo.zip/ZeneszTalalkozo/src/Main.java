import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    private final double DIAK_ESELY = 0.5;
    private static double klasszikAtlagFizetes;
    private static double utcaAtlagFizetes;
    private final int KALAP_DIJ_HATAR = 4000;
    private final String CHAR_SET = "UTF-8";
    private String ADAT_ELERES = "";
    private List<Zenesz> zeneszek = new ArrayList<>();

    public static void main(String[] args) throws IOException {
        new Main().start();

        List<UtcaZenesz> utcaFizetes = new ArrayList<>();
        List<KlasszikusZenesz> klasszik = new ArrayList<>();

        KlasszikusZenesz[] klasszikus = new KlasszikusZenesz[6];
        klasszikus[0] = new KlasszikusZenesz("Nagy Tamás", 20, "Pannon Filmharmonikusok");
        klasszikus[1] = new KlasszikusZenesz("Takács Gáspár", 15, "Mecsek Együttes");
        klasszikus[2] = new KlasszikusZenesz("Balogh Orsolya", 30, "Pannon Filmharmonikusok");
        klasszikus[3] = new KlasszikusZenesz("Horváth Árpád", 15, "Pannon Filmharmonikusok");
        klasszikus[4] = new KlasszikusZenesz("Kiss Péter", 22, "Mecsek Együttes");
        klasszikus[5] = new KlasszikusZenesz("Takács Éva", 10, "Pannon Filmharmonikusok");
        UtcaZenesz[] utca = new UtcaZenesz[4];
        utca[0] = new UtcaZenesz("Kovács Dezső", 10);
        utca[1] = new UtcaZenesz("Kelemen Zoltán", 25);
        utca[2] = new UtcaZenesz("Halász Judit", 12);
        utca[3] = new UtcaZenesz("Varga Gábor", 18);

        klasszikus[0].szerepel();
        klasszikus[1].szerepel();
        klasszikus[2].szerepel();
        klasszikus[3].szerepel();
        klasszikus[4].szerepel();
        klasszikus[5].szerepel();

        int fizet = 0;
        int sum = 0;
        double db = 0;
        for (int i = 0; i < utca.length; i++) {
            fizet = (int) (Math.random() * 5000) + 1;
            utca[0].szerepel();
            utca[0].szerepel();
            utca[1].szerepel();
            utca[2].szerepel();
            utca[2].szerepel();
            utca[2].szerepel();
            utca[3].szerepel();
            utca[3].szerepel();
            utca[i].fizetes(fizet);
            sum += utca[i].fizetes(fizet);
            db++;
            utcaFizetes.add(utca[i]);

        }


        for (int i = 0; i < utcaFizetes.size(); i++) {
            System.out.println(utcaFizetes.get(i));
            utcaFizetes.get(i).diak();
        }
        System.out.println("------------------->");
        utcaAtlagFizetes = sum / db;
        System.out.println("Az utcazenészek átlagfizetése = " + utcaAtlagFizetes);
        System.out.println("------------------->");

        int sum2 = 0;
        double db2 = 0;

        for (int i = 0; i < klasszikus.length; i++) {
            klasszikus[0].szerepel();
            klasszikus[0].szerepel();
            klasszikus[1].szerepel();
            klasszikus[2].szerepel();
            klasszikus[2].szerepel();
            klasszikus[2].szerepel();
            klasszikus[3].szerepel();
            klasszikus[3].szerepel();
            klasszikus[4].szerepel();
            klasszikus[5].szerepel();
            klasszikus[5].szerepel();
            klasszikus[i].fizetes(0);
            sum2 += klasszikus[i].fizetes(0);
            db2++;
            klasszik.add(klasszikus[i]);
        }

        for (int i = 0; i < klasszik.size(); i++) {
            System.out.println(klasszik.get(i));

        }
        System.out.println("------------------->");

        klasszikAtlagFizetes = sum2 / db2;

        System.out.println("A klasszikus zenészek átlagfizetése = " + klasszikAtlagFizetes);
        System.out.println("------------------->");

        atlagFizetesNagyobb();

        utcaFizetes.sort(new Comparator<UtcaZenesz>() {
            @Override
            public int compare(UtcaZenesz o1, UtcaZenesz o2) {
                if (o1.getFizetes() > o2.getFizetes()) {
                    return -1;
                }
                return 1;
            }
        });
        System.out.println("------------------->");
        System.out.println("Az utcazenészek fizetése csökkenő sorrendben : ");
        for (UtcaZenesz a : utcaFizetes) {
            System.out.println(a);
        }

        System.out.println("------------------->");

        klasszik.sort(new Comparator<KlasszikusZenesz>() {
            @Override
            public int compare(KlasszikusZenesz o1, KlasszikusZenesz o2) {
                if (o1.getNettoFizetes() > o2.getNettoFizetes()) {
                    return -1;
                }
                return 1;
            }
        });
        System.out.println("A klasszikus zenészek keresete csökkenő sorrendben : ");
        for (KlasszikusZenesz a : klasszik) {
            System.out.println(a);
        }

    }

    public static void atlagFizetesNagyobb() {
        if (utcaAtlagFizetes > klasszikAtlagFizetes) {
            System.out.println("Az utcazenészek átlagfizetése nagyobb.");
        } else if (utcaAtlagFizetes < klasszikAtlagFizetes) {
            System.out.println("A klasszikus zenészek átlagfizetése nagyobb.");
        } else if (utcaAtlagFizetes == klasszikAtlagFizetes) {
            System.out.println("A zenészek átlagfizetése megegyezik.");
        }
    }
    private void start() throws IOException {
        adatBevitel2();
        zeneles();
    }

    private void adatBevitel() throws IOException {
        try (InputStream ins = this.getClass().getResourceAsStream(ADAT_ELERES);
             Scanner sc = new Scanner(ins, CHAR_SET)) {
            String[] a;
            String sor;
            while (sc.hasNextLine()) {
                sor = sc.nextLine();
                try {
                    if (!sor.isEmpty()) {
                        a = sor.split(";");
                        switch (a.length) {
                            case 3:
                                zeneszek.add(new KlasszikusZenesz(a[0], Integer.parseInt(a[1]), a[2]));
                            case 2:
                                UtcaZenesz utca = new UtcaZenesz(a[0], Integer.parseInt(a[1]));
                                if (Math.random() < DIAK_ESELY) {
                                    utca.setDiak(true);
                                }
                                zeneszek.add(utca);
                                break;
                            default:
                        }
                    }
                } catch (Exception e) {
                    System.out.println("Error");

                }
            }

        }
    }

    private void adatBevitel2() {
        try {
            FileReader file = new FileReader("C:\\Users\\HP\\Desktop\\Java feladatsor\\zeneszek.txt");
            Scanner first = new Scanner(file);
            while (first.hasNext()) {
                String[] a = first.nextLine().split(";");
                for(int i = 0;i<a.length;i++){
                    System.out.println(a[i]+" ");
                }

            }
        } catch (FileNotFoundException e) {
            System.out.println("A fájl nem található");
        }
    }


    public void zeneles() {

        for (Zenesz zenesz : zeneszek) {
            zenesz.szerepel();
            if (zenesz instanceof UtcaZenesz) {
                for (Zenesz tars : zeneszek) {
                    if (!zenesz.equals(tars)) {
                        ((UtcaZenesz) zenesz).fizetes((int) (Math.random()) * KALAP_DIJ_HATAR);
                        System.out.println(tars);

                    }
                }
            }
        }
    }
}



