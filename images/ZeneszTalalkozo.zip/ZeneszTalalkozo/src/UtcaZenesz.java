public class UtcaZenesz extends Zenesz {
    private static final int HELY_PENZ = 1000;
    private int fizetes;
    private boolean diak = false;

    public UtcaZenesz() {

    }

    public UtcaZenesz(String nev, int azonosito) {
        super(nev, azonosito);

    }

    public String toString() {
        return "Utcazenész : név = " + super.getNev() + " azonosító = " + super.getAzonosito() + " fizetes = " + fizetes;

    }

    @Override
    public int fizetes(int penz) {
        fizetes = penz - HELY_PENZ;
        return fizetes;

    }

    public void diak(){
        int diakRandom = (int)(Math.random()*2)+1;
        if(diakRandom==1){
            System.out.println("Diák vagyok");
        }
        else if(diakRandom==2){
            System.out.println("Nem vagyok diák");
        }
    }

    public int getFizetes() {
        return fizetes;
    }

    public void setFizetes(int fizetes) {
        this.fizetes = fizetes;
    }

    public boolean isDiak() {
        return diak;
    }

    public void setDiak(boolean diak) {
        this.diak = diak;
    }
}
