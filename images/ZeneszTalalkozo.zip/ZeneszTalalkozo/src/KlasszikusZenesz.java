public class KlasszikusZenesz extends Zenesz {
    private String zeneKar;
    private int nettoFizetes;
    private static final int ALAP_BER = 150000;
    private static final int FELLEPES_BER = 40000;
    //- adó 30%

    public KlasszikusZenesz(){

    }
    public KlasszikusZenesz(String nev,int azonosito,String zeneKar){
        super(nev,azonosito);
        this.zeneKar = zeneKar;
    }

    public String toString(){
        return "Klasszikus zenész : név = "+super.getNev()+" azonosító = "+super.getAzonosito()+" zenekar neve = "+zeneKar+" fizetés = "+nettoFizetes;
    }

    @Override
    public int fizetes(int penz) {
        int bruttoFizetes = ALAP_BER+(super.getSzereplesekSzama()*FELLEPES_BER);
        double ado = bruttoFizetes*0.3;
        nettoFizetes = (int)(bruttoFizetes-ado);
        return nettoFizetes;
    }

    public int getNettoFizetes() {
        return nettoFizetes;
    }

    public void setNettoFizetes(int nettoFizetes) {
        this.nettoFizetes = nettoFizetes;
    }
}
