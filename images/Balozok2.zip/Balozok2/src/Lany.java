public class Lany extends Balozok {

    private int szavazatokSzama;

    public Lany(){

    }
    public Lany(String nev,String nem, int zsebPenz){
        super(nev,nem,zsebPenz);
    }
    @Override
    public String toString() {
        return "Lany{" +
                "nev='" + super.getNev() + '\'' +
                ", sorSzam=" + super.getSorSzam() +
                ", nem='" + super.getNem() + '\'' +
                ", zsebPenz=" + super.getZsebPenz() +
                ", tancSzam=" + super.getTancSzam() + ", szavazatszám="+szavazatokSzama+", költés="+super.getKoltes()+
                '}';
    }

    public int szavazatotKap(){
        return szavazatokSzama++;
    }

    public int getSzavazatokSzama() {
        return szavazatokSzama;
    }

    public void setSzavazatokSzama(int szavazatokSzama) {
        this.szavazatokSzama = szavazatokSzama;
    }
}
