import java.util.List;

public class Balozok {
    private String nev;
    private int sorSzam;
    private String nem;
    private int zsebPenz;
    private int tancSzam;
    private int koltes;

    public Balozok() {

    }

    public Balozok(String nev, String nem, int zsebPenz) {
        this.nev = nev;
        this.nem = nem;
        this.zsebPenz = zsebPenz;
        sorSzam = IdGenerator.getInstance().getSorSzam();
    }

    @Override
    public String toString() {
        return "Balozok{" +
                "nev='" + nev + '\'' +
                ", sorSzam=" + sorSzam +
                ", nem='" + nem + '\'' +
                ", zsebPenz=" + zsebPenz +
                ", tancSzam=" + tancSzam + ", költés="+koltes+
                '}';
    }
    public int tancol() {
        return tancSzam++;

    }

    public int fogyaszt() {
        koltes = (int)(Math.random()*1500)+1;
        if (zsebPenz < koltes) {
            return zsebPenz;
        }
        else {
            zsebPenz = zsebPenz-koltes;
            return zsebPenz;
        }

    }

    // Begyűjtöttem a lányokat List-be, így csak lányra lehet szavazni!!!
    public void szavaz(List<Lany> lany) {
        int randomLany = (int) (Math.random() * lany.size());
        lany.get(randomLany).szavazatotKap();
        System.out.println("Szavazatot kapott: " + lany.get(randomLany));


    }

    public String getNev() {
        return nev;
    }

    public void setNev(String nev) {
        this.nev = nev;
    }

    public int getSorSzam() {
        return sorSzam;
    }

    public void setSorSzam(int sorSzam) {
        this.sorSzam = sorSzam;
    }

    public String getNem() {
        return nem;
    }

    public void setNem(String nem) {
        this.nem = nem;
    }

    public int getZsebPenz() {
        return zsebPenz;
    }

    public void setZsebPenz(int zsebPenz) {
        this.zsebPenz = zsebPenz;
    }

    public int getTancSzam() {
        return tancSzam;
    }

    public void setTancSzam(int tancSzam) {
        this.tancSzam = tancSzam;
    }

    public int getKoltes() {
        return koltes;
    }

    public void setKoltes(int koltes) {
        this.koltes = koltes;
    }
}
