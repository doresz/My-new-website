public class IdGenerator {
    private static IdGenerator id = null;
    private IdGenerator(){

    }
    public static IdGenerator getInstance(){
        if(id == null){
            id = new IdGenerator();
        }
        return id;
    }
    private int sorSzam;
    public int getSorSzam(){
        sorSzam++;
        return sorSzam;
    }
}
