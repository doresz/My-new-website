public class Fiu extends Balozok {

    public Fiu(){

    }
    public Fiu(String nev,String nem, int zsebPenz){
        super(nev,nem,zsebPenz);
    }
    @Override
    public String toString() {
        return "Fiu{" +
                "nev='" + super.getNev() + '\'' +
                ", sorSzam=" + super.getSorSzam() +
                ", nem='" + super.getNem() + '\'' +
                ", zsebPenz=" + super.getZsebPenz() +
                ", tancSzam=" + super.getTancSzam() + ", költés="+super.getKoltes()+
                '}';
    }
}
