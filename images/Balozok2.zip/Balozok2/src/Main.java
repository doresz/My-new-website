import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static boolean baloznak = true;
    public static void main(String[] args) {
        List<Balozok> bal = new ArrayList<>();
        List<Lany> lany = new ArrayList<>();
        List<Integer> bufeBevetel = new ArrayList<>();
        List<Balozok> balozokk = new ArrayList<>();
        try {
            FileReader reader = new FileReader("C:\\Users\\HP\\Desktop\\balozok.txt");
            Scanner sc = new Scanner(reader);
            while (sc.hasNext()) {
                String[] balozok = sc.nextLine().split(";");
                if (balozok[1].equals("lány")) {
                    bal.add(new Lany(balozok[0], balozok[1], Integer.parseInt(balozok[2])));
                    lany.add(new Lany(balozok[0], balozok[1], Integer.parseInt(balozok[2])));
                }
                if (balozok[1].equals("fiú")) {
                    bal.add(new Fiu(balozok[0], balozok[1], Integer.parseInt(balozok[2])));
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        for (Balozok b : bal) {
            System.out.println(b);
        }
        System.out.println("------------------->");
        while(baloznak) {
            int randomBalozo = (int) (Math.random() * bal.size());
            int randomBalozo2 = (int) (Math.random() * bal.size());
            int randomBalozo3 = (int) (Math.random() * bal.size());
            bal.get(randomBalozo).fogyaszt();
            System.out.println(bal.get(randomBalozo));
            System.out.println(bal.get(randomBalozo).getNev()+" "+bal.get(randomBalozo).getKoltes()+" forintot költött.");
            bal.get(randomBalozo2).tancol();
            System.out.println(bal.get(randomBalozo2));
            System.out.println(bal.get(randomBalozo3)+" szavazott" );
            bal.get(randomBalozo3).szavaz(lany);
            baloznak();
            bufeBevetel.add(bal.get(randomBalozo).getKoltes());
            balozokk.add(bal.get(randomBalozo));
            balozokk.add(bal.get(randomBalozo2));
            balozokk.add(bal.get(randomBalozo3));

        }
        int sum = 0;
        for(Integer a : bufeBevetel){
            sum+=a;
        }
        System.out.println("A büfé összbevétele : "+sum);

        bal.sort(new Comparator<Balozok>() {
            @Override
            public int compare(Balozok o1, Balozok o2) {
                if(o1.getTancSzam()>o2.getTancSzam()){
                    return -1;
                }
                return 0;
            }
        });
        System.out.println("------------------->");
        System.out.println("Bálozók a táncok száma szerint csökkenően: ");
        for(Balozok b : bal){
            System.out.println(b);
        }

        bal.sort(new Comparator<Balozok>() {
            @Override
            public int compare(Balozok o1, Balozok o2) {
                if(o1.getKoltes()<o2.getKoltes()){
                    return -1;
                }
                return 0;
            }
        });
        System.out.println("------------------->");
        System.out.println("A bálozók fogyasztás szerint növekvő sorrendben : ");
        for(Balozok b : bal){
            System.out.println(b);
        }

      lany.sort(new Comparator<Lany>() {
          @Override
          public int compare(Lany o1, Lany o2) {
              if(o1.getSzavazatokSzama()>o2.getSzavazatokSzama()){
                  return -1;
              }
              return 0;
          }
      });
        System.out.println("------------------->");
        System.out.println("A lányok szavazat szerint csökkenően: ");
        for(Lany l : lany){
            System.out.println(l);
        }

        System.out.println("------------->");
        System.out.println("A bálozók listája : ");
        for(Lany l : lany){
            if(l.getSzavazatokSzama()>0){
                System.out.println(l);
            }
        }
        for(Balozok b : balozokk){
            System.out.println(b);
        }


    }
    public static void baloznak(){
        String[] b = {"Vége a bálnak", "Még tart a bál"};
        int random = (int) (Math.random() * b.length);
        if(b[random].equals(b[0])){
            baloznak = false;
            System.out.println("Vége a bálnak");
        }
        else{
            System.out.println(b[1]);
        }
    }
}
