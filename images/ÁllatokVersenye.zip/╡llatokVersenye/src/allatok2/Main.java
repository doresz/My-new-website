package allatok2;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[]args){
        List<Állatok> allat = new ArrayList<>();
        try {
            FileReader reader = new FileReader("C:\\Users\\HP\\Downloads\\allatok.txt");
            Scanner sc = new Scanner(reader);
            while(sc.hasNext()){
                String[] animal = sc.nextLine().split(";");
                if(animal[0].equals("Cirmos")){
                    allat.add(new Macska(animal[0],Integer.parseInt(animal[1]),Boolean.parseBoolean(animal[2])));
                }
                else if(animal[0].equals("Picúr")){
                    allat.add(new Macska(animal[0],Integer.parseInt(animal[1]),Boolean.parseBoolean(animal[2])));
                }
                else if(animal[0].equals("Bolhazsák")){
                    allat.add(new Macska(animal[0],Integer.parseInt(animal[1]),Boolean.parseBoolean(animal[2])));
                }
                else{
                    allat.add(new Kutya(animal[0],Integer.parseInt(animal[1])));
                }

                }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        for(Állatok a : allat){
            int szepsegPont = (int)(Math.random()*10)+1;
            int viselkedesPont = (int)(Math.random()*10)+1;
            a.kor();
            if(a instanceof Kutya){
                ((Kutya) a).viszonyPont();

            }
            a.pontoz(szepsegPont,viselkedesPont);
            System.out.println(a);
        }

    }
}
