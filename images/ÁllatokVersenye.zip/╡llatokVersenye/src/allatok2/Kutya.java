package allatok2;

public class Kutya extends Állatok{
    private int viszonyPont;
    private int pontSzam;

    public Kutya(){

    }
    public Kutya(String nev,int szuletesiEv){
        super(nev,szuletesiEv);
    }
    @Override
    public String toString() {
        return "Kutya{" + "rajtszám="+super.getRajtSzam()+
                " nev='" + super.getNev() + '\'' +
                ", szuletesiEv=" + super.getSzuletesiEv() +
                ", pontSzam=" + pontSzam +
                ", kor=" + super.getKor() + ", viszonypont="+viszonyPont+
                '}';
    }
    @Override
    public int pontoz(int szepsegPont,int viselkedesPont){
        pontSzam = super.getPontSzam();
        if(super.getKor()>Állatok.getKorHatar()){
            pontSzam = 0;
        }
        else{
            pontSzam = viszonyPont+(((Állatok.getMaxKor()-super.getKor())*szepsegPont)+(2*viselkedesPont));
        }
        return pontSzam;

    }
    public int viszonyPont(){
        viszonyPont = (int)(Math.random()*12)+1;
        return viszonyPont;
    }


    }




