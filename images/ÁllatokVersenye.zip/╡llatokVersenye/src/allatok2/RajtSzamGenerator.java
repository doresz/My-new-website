package allatok2;

public class RajtSzamGenerator {
    private static RajtSzamGenerator rsz = null;
    private RajtSzamGenerator(){

    }
    public static RajtSzamGenerator getInstance(){
        if(rsz == null){
            rsz = new RajtSzamGenerator();
        }
        return rsz;
    }

    private int rajtSzam;
    public int azonosito(){
        rajtSzam++;
        return rajtSzam;
    }
}
