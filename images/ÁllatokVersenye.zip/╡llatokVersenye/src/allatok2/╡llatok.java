package allatok2;

public abstract class Állatok {
    private String nev;
    private int szuletesiEv;
    private int pontSzam;
    private static final int ACTUAL_YEAR = 2020;
    private int kor;
    private static final int KOR_HATAR = 8;
    private static final int MAX_KOR = 10;
    private int rajtSzam;

    public Állatok(){

    }
    public Állatok(String nev, int szuletesiEv){
        this.nev = nev;
        this.szuletesiEv = szuletesiEv;
        rajtSzam = RajtSzamGenerator.getInstance().azonosito();

    }

    @Override
    public String toString() {
        return "Állatok{" + "rajtszám="+rajtSzam+
                " nev='" + nev + '\'' +
                ", szuletesiEv=" + szuletesiEv +
                ", pontSzam=" + pontSzam +
                ", kor=" + kor +
                '}';
    }
    public abstract int pontoz(int szepsegPont,int viselkedesPont);


    public int kor(){
        kor = ACTUAL_YEAR-szuletesiEv;
        return kor;
    }

    public int getPontSzam() {
        return pontSzam;
    }

    public String getNev() {
        return nev;
    }

    public int getSzuletesiEv() {
        return szuletesiEv;
    }

    public static int getActualYear() {
        return ACTUAL_YEAR;
    }

    public int getKor() {
        return kor;
    }

    public static int getKorHatar() {
        return KOR_HATAR;
    }

    public static int getMaxKor() {
        return MAX_KOR;
    }

    public int getRajtSzam() {
        return rajtSzam;
    }
}
