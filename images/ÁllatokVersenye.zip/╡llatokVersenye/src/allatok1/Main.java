package allatok1;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[]args){
        List<Állatok> allat = new ArrayList<>();
        try {
            FileReader reader = new FileReader("C:\\Users\\HP\\Downloads\\allatok.txt");
            Scanner sc = new Scanner(reader);
            while(sc.hasNext()){
                String[] file = sc.nextLine().split(";");
                allat.add(new Állatok(file[0],Integer.parseInt(file[1])));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        for(Állatok a : allat){
            a.kor();
            System.out.println(a);
        }

        System.out.println("------------->");
        for(Állatok a : allat){
            int szepsegPont = (int)(Math.random()*10)+1;
            int viselkedesPont = (int)(Math.random()*10)+1;
            a.pontoz(szepsegPont,viselkedesPont);
            System.out.println(a);
        }
        allat.sort(new Comparator<Állatok>() {
            @Override
            public int compare(Állatok o1, Állatok o2) {
                if(o1.getPontSzam()>o2.getPontSzam()){
                    return -1;
                }

                return 0;
            }
        });
        System.out.println("------------->");
        System.out.println("Pontszámok csökkenő sorrendben : ");
        for(Állatok a : allat){
            System.out.println(a);
        }

        System.out.println("------------->");
        System.out.println("A győztes(ek): ");

        allat.sort(new Comparator<Állatok>() {
            @Override
            public int compare(Állatok o1, Állatok o2) {
                if(allat.get(0).getPontSzam() == o1.getPontSzam()){
                    System.out.println(o1);
                    return 0;
                }
                else if(allat.get(0).getPontSzam() == o2.getPontSzam()){
                    System.out.println(o2);
                    return 0;
                }
                return 0;
            }
        });


    }
}
