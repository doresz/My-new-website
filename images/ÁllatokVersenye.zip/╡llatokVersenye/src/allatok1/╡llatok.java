package allatok1;

public class Állatok {
    private String nev;
    private int szuletesiEv;
    private int pontSzam;
    private static final int ACTUAL_YEAR = 2020;
    private int kor;
    private static final int KOR_HATAR = 8;
    private static final int MAX_KOR = 10;

    public Állatok(){

    }
    public Állatok(String nev, int szuletesiEv){
        this.nev = nev;
        this.szuletesiEv = szuletesiEv;

    }

    @Override
    public String toString() {
        return "Állatok{" +
                "nev='" + nev + '\'' +
                ", szuletesiEv=" + szuletesiEv +
                ", pontSzam=" + pontSzam +
                ", kor=" + kor +
                '}';
    }
    public int pontoz(int szepsegPont,int viselkedesPont){
        if(kor>KOR_HATAR){
            pontSzam = 0;
        }
        else{
            pontSzam = ((MAX_KOR-kor)*szepsegPont)+(2*viselkedesPont);
        }
        return pontSzam;

        }

    public int kor(){
        kor = ACTUAL_YEAR-szuletesiEv;
        return kor;
    }

    public int getPontSzam() {
        return pontSzam;
    }
}
