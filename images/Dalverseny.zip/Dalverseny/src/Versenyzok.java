public class Versenyzok {
    private String nev;
    private String szak;
    private int rajtSzam;
    private int pontSzam;

    public Versenyzok() {

   }

    public Versenyzok(String nev, String szak) {
        this.nev = nev;
        this.szak = szak;
        rajtSzam = IdGenerator.getInstance().rajtSzam();

    }

    @Override
    public String toString() {
        return "Versenyzok{" + " rajtSzam=" + rajtSzam +
                " nev='" + nev + '\'' +
                ", szak='" + szak + '\'' +
                ", pontSzam=" + pontSzam +
                '}';
    }

    public int pontoz(int ertek) {
        pontSzam = pontSzam+ertek;
        return pontSzam;
    }

    public String getSzak() {
        return szak;
    }


    public int getPontSzam() {
        return pontSzam;
    }

}
