import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.*;

public class Main {
    private static final int ZsurikSzama = 10;

    public static void main(String[] args) {
        List<Versenyzok> verseny = new ArrayList<>();
        try {
            FileReader reader = new FileReader("C:\\Users\\HP\\Downloads\\01_feladatsor_adatai\\versenyzok.txt");
            Scanner sc = new Scanner(reader);
            while (sc.hasNext()) {
                String[] versenyzok = sc.nextLine().split(";");
                verseny.add(new Versenyzok(versenyzok[0], versenyzok[1]));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }




        for (Versenyzok v : verseny) {
            System.out.println(v);

        }
        System.out.println("------------->");

        int x = 0;
        while (x < ZsurikSzama) {

            for (Versenyzok v : verseny) {
                int pontErtek = (int) (Math.random() * 10) + 1;
                v.pontoz(pontErtek);
            }
            x++;
        }

        for (Versenyzok v : verseny) {
            System.out.println(v);
        }

        verseny.sort(new Comparator<Versenyzok>() {
            @Override
            public int compare(Versenyzok o1, Versenyzok o2) {
                if (o1.getPontSzam() > o2.getPontSzam()) {
                    return -1;
                }
                return 0;
            }
        });

        System.out.println("------------->");
        System.out.println("A versenyzők pontszám szerint csökkenő sorrendben");

        for (Versenyzok v : verseny) {
            System.out.println(v);
        }

        System.out.println("------------->");
        System.out.println("A legtöbb pontszámot kapott versenyzők : ");

        verseny.sort(new Comparator<Versenyzok>() {
            @Override
            public int compare(Versenyzok o1, Versenyzok o2) {
                if (verseny.get(0).getPontSzam() == o1.getPontSzam()) {
                    System.out.println(o1);
                    return 0;
                } else if (verseny.get(0).getPontSzam() == o2.getPontSzam()) {
                    System.out.println(o2);
                    return 0;

                }
                return 1;
            }
        });

        System.out.println("------------->");

        szak("informatikus", verseny);
        System.out.println("------------->");

        boolean folyamatosKereses = true;

        while(folyamatosKereses) {
            Scanner szakKereses = new Scanner(System.in);
            System.out.println("Írja be a keresni kívánt szakágat!");
            String input = szakKereses.nextLine();
            for (Versenyzok v : verseny) {
                if (v.getSzak().equals(input)) {
                    System.out.println(v);
                }
            }
        }

    }

    public static void szak(String szak, List<Versenyzok> verseny) {
        for (Versenyzok v : verseny) {
            if (v.getSzak().equals(szak)) {
                System.out.println(v);
            }

        }
    }
}

