package com.animal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        Dog dog = new Dog(1,"Bodri",2010);
        dog.setKorHatar(9);
        dog.setViszonyPont(10);
        dog.addPointsDog();
        Dog dog2 = new Dog(2,"Rexi",2013);
        dog2.setViszonyPont(3);
        dog2.addPointsDog();
        Cat cat = new Cat(3,"Cirmos",2011);
        cat.setCatBox(true);
        cat.addPointsCat();
        Dog dog3 = new Dog(4,"Pamacs",2015);
        dog3.setViszonyPont(0);
        dog3.addPointsDog();
        Cat cat2 = new Cat(5,"Bolhzsák",2016);
        cat2.setCatBox(true);
        cat2.addPointsCat();
        Dog dog4 = new Dog(6,"Buksi",2010);
        dog4.setViszonyPont(12);
        dog4.addPointsDog();
        Cat cat3 = new Cat(7,"Picúr",2012);
        cat3.setCatBox(false);
        cat3.addPointsCat();




        ArrayList<String> list = new ArrayList<>();
        Animal[] an = new Animal[7];




    }
}
