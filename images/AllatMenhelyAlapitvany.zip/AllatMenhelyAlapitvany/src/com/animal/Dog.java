package com.animal;

import java.util.Comparator;

public class Dog extends Animal  {
    private int viszonyPont;
    private int beauty;
    private int behaviour;
    private static int korHatar;
    private int point;

    public Dog(){

    }
    public Dog(int rajtszam,String name,int birthYear){
        super(rajtszam,name,birthYear);

    }

    public void addPointsDog() {
        int kor = this.age();
        if (kor > Animal.getKorHatar()) {
            this.point = 0;
        } else if (viszonyPont == 0) {
            this.point = 0;
        } else {
            this.point = (Animal.getKorHatar() - kor) * (beauty+viszonyPont) + (kor * (behaviour+viszonyPont));
        }
        System.out.println("Pontszám: "+ point);
    }

    public int getViszonyPont() {
        return viszonyPont;
    }

    public void setViszonyPont(int viszonyPont) {
        this.viszonyPont = viszonyPont;
        }
    }



