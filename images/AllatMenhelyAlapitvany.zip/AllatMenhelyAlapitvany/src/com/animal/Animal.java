package com.animal;

import java.util.ArrayList;
import java.util.Comparator;

public class Animal {
    private String name;
    private int birthYear;
    private static int actualYear = 2020;
    private static final int max_Age = 10;
    private int point;
    private int beauty;
    private int behaviour;
    private static int korHatar;
    private int rajtSzam;

    public int getRajtSzam() {
        return rajtSzam;
    }

    public Animal() {

    }

    public Animal(int rajtSzam, String name, int birthYear) {
        this.rajtSzam = rajtSzam;
        this.name = name;
        this.birthYear = birthYear;
        System.out.println(rajtSzam+" "+name + " " + birthYear);

    }

    public String toString() {

        return name + " " + age() + " éves " + point + " pont.";
    }

    public int age() {
        return actualYear - birthYear;
    }

    public int addBeautyPoints() {
        beauty = (int) (Math.random() * 10) + 1;
        return beauty;
    }

    public int addBehaviourPoints() {
        behaviour = (int) (Math.random() * 10) + 1;
        return behaviour;

    }

    public String getName() {
        return name;
    }

    public int getBirthYear() {
        return birthYear;
    }

    public int getPoint() {
        return point;
    }

    public void setKorHatar(int korHatar) {
        this.korHatar = korHatar;
        System.out.println("A korhatár: " + korHatar + " év.");
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBirthYear(int birthYear) {
        this.birthYear = birthYear;
    }

    public static int getActualYear() {
        return actualYear;
    }

    public static void setActualYear(int actualYear) {
        Animal.actualYear = actualYear;
    }

    public static int getMax_Age() {
        return max_Age;
    }

    public void setPoint(int point) {
        this.point = point;
    }

    public int getBeauty() {
        return beauty;
    }

    public void setBeauty(int beauty) {
        this.beauty = beauty;
    }

    public int getBehaviour() {
        return behaviour;
    }

    public void setBehaviour(int behaviour) {
        this.behaviour = behaviour;
    }

    public static int getKorHatar() {
        return korHatar;
    }

    public void setRajtSzam(int rajtSzam) {
        this.rajtSzam = rajtSzam;
    }


}
