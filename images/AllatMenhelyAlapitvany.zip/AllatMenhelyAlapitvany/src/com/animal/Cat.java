package com.animal;

public class Cat extends Animal {
    private static boolean catBox;
    private int point;
    private int beauty;
    private int behaviour;
    private static int korHatar;

    public Cat(){

    }

    public Cat(int rajtszam,String name,int birthYear){
        super(rajtszam,name,birthYear);

    }

    public void addPointsCat() {
        beauty = addBehaviourPoints();
        behaviour = addBehaviourPoints();
        int kor = this.age();
        if (kor > Animal.getKorHatar()) {
            this.point = 0;
        } else if (catBox == false) {
            this.point = 0;
        } else {
            this.point = (Animal.getKorHatar() - kor) * beauty + (kor * behaviour);
        }
        System.out.println("Pontszám: " + point);
    }

    public void setCatBox(boolean catBox) {
        this.catBox = catBox;
        if(catBox){
            System.out.println("Van doboza");
        }
        else{
            System.out.println("Nincs doboza");
        }
    }

    public static boolean isCatBox() {
        return catBox;
    }
}
