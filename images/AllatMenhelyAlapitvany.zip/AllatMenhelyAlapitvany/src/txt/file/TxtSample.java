package txt.file;

import java.io.*;
import java.util.*;

public class TxtSample {
    public static void main(String[]args) throws IOException {
       File file = new File("C:\\Users\\HP\\Downloads\\allatok.txt");
       Scanner first = new Scanner(file);
       while(first.hasNext()){
           String[] tokens = first.nextLine().split(";");
           String first1 = tokens[0];
           System.out.println(first1);
           String last = tokens[tokens.length - 1];
       }

       ArrayList<String> array = new ArrayList<>();
       array.add("krumpli");
       array.add("salata");
       array.add("repa");
       array.add("csoki");

       Collections.sort(array);
       compare(array);


    }

    public static void compare(ArrayList<String> e){
        for(String s:e){
            System.out.println(s);
        }


    }
}
