package egyetemistak;

public class Egyetemistak {
    private String azonosito;
    private int tanulasiIdo;
    private double fogyasztottAlkohol;
    private static final int TANULAS_SZORZO = 3;
    private static final int ALKOHOL_SZORZO = 3;

    public Egyetemistak() {

    }

    public Egyetemistak(String azonosito) {
        this.azonosito = azonosito;
    }

    @Override
    public String toString() {
        return "Egyetemistak : azonosito = "+ azonosito+"tanulasiIdo = "+ tanulasiIdo + "fogyasztott alkohol = "+fogyasztottAlkohol;

    }

    public void oranVan() {

    }

    public int tanul(int ido) {
        this.tanulasiIdo = ido;
        return tanulasiIdo++;

    }

    public double kocsmazik(double alkohol) {
        this.fogyasztottAlkohol = alkohol;
        return fogyasztottAlkohol++;

    }

    public int tudas() {
        return (tanulasiIdo * TANULAS_SZORZO) - ((int) fogyasztottAlkohol * ALKOHOL_SZORZO);
    }

    public String getAzonosito() {
        return azonosito;
    }

    public void setAzonosito(String azonosito) {
        this.azonosito = azonosito;
    }

    public int getTanulasiIdo() {
        return tanulasiIdo;
    }

    public void setTanulasiIdo(int tanulasiIdo) {
        this.tanulasiIdo = tanulasiIdo;
    }

    public double getFogyasztottAlkohol() {
        return fogyasztottAlkohol;
    }

    public void setFogyasztottAlkohol(double fogyasztottAlkohol) {
        this.fogyasztottAlkohol = fogyasztottAlkohol;
    }
}
