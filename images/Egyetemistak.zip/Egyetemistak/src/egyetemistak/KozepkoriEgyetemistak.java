package egyetemistak;

public class KozepkoriEgyetemistak extends Egyetemistak {
    private int vitaKeszseg;
    private static final int SZORZO = 4;

    public KozepkoriEgyetemistak() {

    }

    public KozepkoriEgyetemistak(String azonosito) {
        super(azonosito);

    }
    @Override
    public void oranVan(){
        vitaKeszseg++;


    }

    @Override
    public String toString() {
        return "KozepkoriEgyetemistak: azonosító = " +super.getAzonosito()+" vitakészség = "+vitaKeszseg+
                 " tanulási idő = "+super.getTanulasiIdo()+" fogyasztott alkohol = "+super.getFogyasztottAlkohol();

    }

    public int tudas(){
        return super.tudas()+vitaKeszseg*SZORZO;
    }

}
