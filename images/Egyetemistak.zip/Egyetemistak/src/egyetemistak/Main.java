package egyetemistak;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Egyetemistak> tudas = new ArrayList<>();
        List<Egyetemistak> kozepTanul = new ArrayList<>();
        List<Egyetemistak> maiTanul = new ArrayList<>();
        Egyetemistak[] egyetem = new Egyetemistak[9];
        egyetem[0] = new MaiEgyetemistak("M001");
        egyetem[1] = new MaiEgyetemistak("M002");
        egyetem[2] = new MaiEgyetemistak("M003");
        egyetem[3] = new MaiEgyetemistak("M004");
        egyetem[4] = new MaiEgyetemistak("M005");
        egyetem[5] = new KozepkoriEgyetemistak("K001");
        egyetem[6] = new KozepkoriEgyetemistak("K002");
        egyetem[7] = new KozepkoriEgyetemistak("K003");
        egyetem[8] = new KozepkoriEgyetemistak("K004");

        List<Egyetemistak> list = new ArrayList<>();
        list.add(egyetem[0]);
        list.add(egyetem[1]);
        list.add(egyetem[2]);
        list.add(egyetem[3]);
        list.add(egyetem[4]);
        list.add(egyetem[5]);
        list.add(egyetem[6]);
        list.add(egyetem[7]);
        list.add(egyetem[8]);


        for (int i = 0; i < 10; i++) {
            int random = (int) (Math.random() * list.size());
            int randomTanul = (int) (Math.random() * 90) + 1;
            int randomKocsma = (int) (Math.random() * 120) + 1;
            int[] tanulKocsma = {list.get(random).tanul(randomTanul), (int) list.get(random).kocsmazik(randomKocsma)};
            int tanulKocs = (int) (Math.random() * tanulKocsma.length);
            int a = tanulKocsma[tanulKocs];
            list.get(random).oranVan();
            System.out.println(list.get(random));
            tudas.add(list.get(random));

        }
        System.out.println("---------------------->");

        for(int i = 0;i<tudas.size();i++){
            if(tudas.get(i)==egyetem[0]){
                maiTanul.add(tudas.get(i));
            }
            else if(tudas.get(i)==egyetem[1]){
                maiTanul.add(tudas.get(i));
            }
            else if(tudas.get(i)==egyetem[2]){
                maiTanul.add(tudas.get(i));
            }
            else if(tudas.get(i)==egyetem[3]){
                maiTanul.add(tudas.get(i));
            }
            else if(tudas.get(i)==egyetem[4]){
                maiTanul.add(tudas.get(i));
            }
            if(tudas.get(i)==egyetem[5]){
                kozepTanul.add(tudas.get(i));
            }
            else if(tudas.get(i)==egyetem[6]){
                kozepTanul.add(tudas.get(i));
            }
            else if(tudas.get(i)==egyetem[7]){
                kozepTanul.add(tudas.get(i));
            }
            else if(tudas.get(i)==egyetem[8]){
                kozepTanul.add(tudas.get(i));
            }
        }
        int sum = 0;
        double db = 0;
        for(int i = 0;i<kozepTanul.size();i++){
            sum+=kozepTanul.get(i).getTanulasiIdo();
            db++;
        }
        double kozepAtlag = sum/db;
        System.out.println("A középkori tanulók tanulási idő átlaga: "+kozepAtlag);

        System.out.println("---------------------->");

        Collections.sort(kozepTanul, new Comparator<Egyetemistak>() {
            @Override
            public int compare(Egyetemistak o1, Egyetemistak o2) {
                if(o1.getTanulasiIdo()>o2.getTanulasiIdo()){
                    return -1;
                }

                return 1;
            }
        });
        System.out.println("A középkori tanulók közül a legtöbbet tanult(ak) : ");
        Collections.sort(kozepTanul, new Comparator<Egyetemistak>() {
            @Override
            public int compare(Egyetemistak o1, Egyetemistak o2) {
                if(kozepTanul.get(0).getTanulasiIdo()==o1.getTanulasiIdo()){
                    System.out.println(o1);
                    return 0;
                }
                if(kozepTanul.get(0).getTanulasiIdo()==o2.getTanulasiIdo()){
                    System.out.println(o2);
                    return 0;
                }

                return 1;
            }
        });

        System.out.println("---------------------->");

        int sum2 = 0;
        double db2 = 0;
        for(int i = 0;i<maiTanul.size();i++){
            sum2+=maiTanul.get(i).getTanulasiIdo();
            db2++;
        }
        double maiAtlag = sum2/db2;
        System.out.println("A mai egyetemisták átlag tanulási ideje : "+maiAtlag);

        System.out.println("---------------------->");

        Collections.sort(maiTanul, new Comparator<Egyetemistak>() {
            @Override
            public int compare(Egyetemistak o1, Egyetemistak o2) {
                if(o1.getTanulasiIdo()>o2.getTanulasiIdo()){
                    return -1;
                }
                return 1;
            }
        });
        System.out.println("A mai tanulók közül a legtöbbet tanult(ak) : ");
        Collections.sort(maiTanul, new Comparator<Egyetemistak>() {
            @Override
            public int compare(Egyetemistak o1, Egyetemistak o2) {
                if(maiTanul.get(0).getTanulasiIdo()==o1.getTanulasiIdo()){
                    System.out.println(o1);
                    return 0;
                }
                if(maiTanul.get(0).getTanulasiIdo()==o2.getTanulasiIdo()){
                    System.out.println(o2);
                    return 0;
                }
                return 1;
            }
        });
        System.out.println("---------------------->");

        if(maiAtlag>kozepAtlag){
            System.out.println("A mai egyetemistáknak több az atlag tanulási ideje : "+maiAtlag);
        }
        else if(maiAtlag<kozepAtlag){
            System.out.println("A középkori egyetemistáknak több az átlag tanulási ideje : "+kozepAtlag);
        }

        kozepTanul.sort(new Comparator<Egyetemistak>() {
            @Override
            public int compare(Egyetemistak o1, Egyetemistak o2) {
                if(o1.getFogyasztottAlkohol()>o2.getFogyasztottAlkohol()){
                    return -1;
                }
                return 0;
            }
        });
        System.out.println("A legtöbb alkoholt fogyasztó középkori egyetemisták : ");
        kozepTanul.sort(new Comparator<Egyetemistak>() {
            @Override
            public int compare(Egyetemistak o1, Egyetemistak o2) {
                if(kozepTanul.get(0).getFogyasztottAlkohol()==o1.getFogyasztottAlkohol()){
                    System.out.println(o1);
                    return 0;
                }
                if(kozepTanul.get(0).getFogyasztottAlkohol()==o2.getFogyasztottAlkohol()){
                    System.out.println(o2);
                    return 0;
                }
                return 0;
            }
        });

       maiTanul.sort(new Comparator<Egyetemistak>() {
           @Override
           public int compare(Egyetemistak o1, Egyetemistak o2) {
               if(o1.getFogyasztottAlkohol()>o2.getFogyasztottAlkohol()){
                   return -1;
               }
               return 1;
           }
       });

        System.out.println("---------------------->");
        System.out.println("A legtöbbet ivó mai egyetemisták: ");

        maiTanul.sort(new Comparator<Egyetemistak>() {
            @Override
            public int compare(Egyetemistak o1, Egyetemistak o2) {
                if(maiTanul.get(0).getFogyasztottAlkohol()==o1.getFogyasztottAlkohol()){
                    System.out.println(o1);
                    return 0;
                }
                if(maiTanul.get(0).getFogyasztottAlkohol()==o2.getFogyasztottAlkohol()){
                    System.out.println(o2);
                    return 0;
                }
                return 1;
            }
        });







    }
}




        








