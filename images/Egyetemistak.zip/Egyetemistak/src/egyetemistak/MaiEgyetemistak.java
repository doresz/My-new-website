package egyetemistak;

public class MaiEgyetemistak extends Egyetemistak {
    private int kutyuHasznalatSzam;
    private static final int ALLANDO = 5;

    public MaiEgyetemistak(){

    }
    public MaiEgyetemistak(String azonosito){
        super(azonosito);

    }
    @Override
    public void oranVan(){
        kutyuHasznalatSzam+=ALLANDO;

    }

    @Override
    public String toString() {
        return "MaiEgyetemistak: azonosítő = "+super.getAzonosito()+
                " kutyuHasznalatSzam = " + kutyuHasznalatSzam + " tanulási idő = "+super.getTanulasiIdo()+" fogyasztott alkohol = "+super.getFogyasztottAlkohol();
    }
}
