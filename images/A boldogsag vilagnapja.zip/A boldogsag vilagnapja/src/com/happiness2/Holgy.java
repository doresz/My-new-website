package com.happiness2;

public class Holgy extends Ember2 {
    int gyermekekSzama;

    public Holgy(String azonosito,int szuletesiEv,int gyerek){
        super(azonosito, szuletesiEv);
        this.gyermekekSzama = gyerek;


    }

    @Override
    public String toString() {
        return "Holgy{" +
                "gyermekekSzama=" + gyermekekSzama+
                ", azonosito='" + azonosito + '\'' +
                ", szuletesiEv=" + szuletesiEv +
                '}';
    }

    public int getGyermekekSzama() {
        return gyermekekSzama;
    }
}
