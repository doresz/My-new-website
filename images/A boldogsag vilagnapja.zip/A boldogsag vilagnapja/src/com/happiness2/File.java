package com.happiness2;

import com.happiness2.Ember2;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class File {
    private static final int ACTUAL_YEAR = 2020;
    public static void main(String[] args) {
        List<Ferfi> ferfi = new ArrayList<>();
        List<Holgy> holgy = new ArrayList<>();
        List<Ember2> ember2 = new ArrayList<>();
        FileReader file = null;
        try {
            file = new FileReader("C:\\Users\\HP\\Desktop\\Java feladatsor\\emberek.txt");
            Scanner first = new Scanner(file);
            while (first.hasNext()) {
                String[] a = first.nextLine().split(";");
                ember2.add(new Ember2(a[0], Integer.parseInt(a[1])));
                if (a[0].charAt(0) == 'N') {
                    holgy.add(new Holgy(a[0], Integer.parseInt(a[1]), Integer.parseInt(a[2])));
                }
                /*Vmiert az első elemet kihagyja, ha charAt(0)=='F'-et írok*/

                if (a[0].charAt(0) != 'N') {
                    ferfi.add(new Ferfi(a[0], Integer.parseInt(a[1])));
                }

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        for (Ember2 e : ember2) {
            System.out.println(e);
        }

        System.out.println("-------------------->");

        for (Holgy e : holgy) {
            System.out.println(e);
        }

        System.out.println("-------------------->");

        for (Ferfi e : ferfi) {
            System.out.println(e);
        }

        ember2.sort(new Comparator<Ember2>() {
            @Override
            public int compare(Ember2 o1, Ember2 o2) {
                if (o1.getSzuletesiEv() < o2.getSzuletesiEv()) {
                    return -1;
                }
                return 0;
            }
        });
        System.out.println("-------------------->");
        System.out.println("Születési sorrend : ");
        int sum2 = 0;
        double db2 = 0;
        double atlagEletKor = 0;
        for (Ember2 e : ember2) {
            sum2+=e.getSzuletesiEv();
            db2++;
            System.out.println(e);
        }
        atlagEletKor = ACTUAL_YEAR-(sum2/db2);
        System.out.println("-------------------->");
        System.out.println("Átlagéletkor = "+atlagEletKor);

        holgy.sort(new Comparator<Holgy>() {
            @Override
            public int compare(Holgy o1, Holgy o2) {
                if(o1.getGyermekekSzama()<o2.getGyermekekSzama()){
                    return -1;
                }
                return 0;
            }
        });
        int sum = 0;
        double db = 0;
        System.out.println("A hólgyek gyermekek száma szerinti sorrendben : ");
        for(Holgy e : holgy){
            sum+=e.getGyermekekSzama();
            db++;
            System.out.println(e);
        }
        System.out.println("A gyermekek számának átlaga = "+sum/db);


    }
}

