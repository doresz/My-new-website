package com.happiness2;

public class Ember2 {
    String azonosito;
    int szuletesiEv;



    public Ember2(){

    }

    public Ember2(String azonosito, int szuletesiEv) {
        this.azonosito = azonosito;
        this.szuletesiEv = szuletesiEv;

    }

    @Override
    public String toString() {
        return "Ember2{" +
                "azonosito='" + azonosito + '\'' +
                ", szuletesiEv='" + szuletesiEv + '\'' +
                '}';
    }

    public String getAzonosito() {
        return azonosito;
    }

    public int getSzuletesiEv() {
        return szuletesiEv;
    }

}
