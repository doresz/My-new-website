package com.happiness2;

public class Ferfi extends Ember2 {


    public Ferfi(String azonosito,int szuletesiEv){
        super(azonosito,szuletesiEv);

    }

    @Override
    public String toString() {
        return "Ferfi{" +
                "azonosito='" + azonosito + '\'' +
                ", szuletesiEv=" + szuletesiEv +
                '}';
    }
}
