package com.happiness;

public class Holgy extends Ember {
    private int gyerekekSzama;
    private int boldogsagErtek;
    private static final int BOLDOGSAG_SZORZO = 2;

    public Holgy(){

    }
    public Holgy(int szuletesiEv,int gyerekekSzama){
        super(szuletesiEv);
        this.gyerekekSzama = gyerekekSzama;
    }
    public String toString(){
        return "Hölgy azonosító = "+super.getAzonosito()+" nem = Hölgy"+" boldogságérték = "+boldogsagErtek+" gyerekek száma = "+gyerekekSzama;
    }
    @Override
    public int boldogsagErtek(int mutato){
        this.boldogsagErtek = super.getBoldogsagErtek();
        boldogsagErtek = mutato+(gyerekekSzama*BOLDOGSAG_SZORZO);
        return super.getBoldogsagErtek();
    }
    public int szul(int UjSzulott){
        gyerekekSzama+=UjSzulott;
        return gyerekekSzama;
    }

    public int getGyerekekSzama() {
        return gyerekekSzama;
    }

    public void setGyerekekSzama(int gyerekekSzama) {
        this.gyerekekSzama = gyerekekSzama;
    }

    public int getBoldogsagErtek() {
        return boldogsagErtek;
    }

    public void setBoldogsagErtek(int boldogsagErtek) {
        this.boldogsagErtek = boldogsagErtek;
    }
}
