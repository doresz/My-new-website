package com.happiness;

public class Férfi extends Ember {
    private int sikeresseg;
    private int boldogsagErtek;

    public Férfi() {

    }

    public Férfi(int szuletesiEv) {
        super(szuletesiEv);
    }

    public String toString() {
        return "Férfi azonosító = " + super.getAzonosito() + " nem = Férfi" + " boldogságértéke = " + boldogsagErtek;
    }

    public int sikeres() {
        sikeresseg = (int) (Math.random() * 10);
        return sikeresseg;
    }

    @Override
    public int boldogsagErtek(int mutato) {
        this.boldogsagErtek = super.getBoldogsagErtek();
        boldogsagErtek = mutato + (sikeresseg / super.kor());
        return super.getBoldogsagErtek();
    }

    public int getSikeresseg() {
        return sikeresseg;
    }

    public void setSikeresseg(int sikeresseg) {
        this.sikeresseg = sikeresseg;
    }

    public int getBoldogsagErtek() {
        return boldogsagErtek;
    }

    public void setBoldogsagErtek(int boldogsagErtek) {
        this.boldogsagErtek = boldogsagErtek;
    }
}
