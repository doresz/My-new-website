package com.happiness;

public abstract class Ember {
    private String azonosito;
    private String nem;
    private int szuletesiEv;
    private int kor;
    private int segites;
    private int boldogsagErtek;
    private static final int AKTUALIS_EV = 2020;


    public Ember(){

    }
    public Ember(int szuletesiEv){
        azonosito = IdGenerator.getInstance().getEgyediAzonosito(this);
        this.szuletesiEv = szuletesiEv;
    }

    @Override
    public String toString() {
        return "Ember{" +
                "azonosito='" + azonosito + '\'' +
                ", nem='" + nem + '\'' +
                +
                '}';
    }
    public int segites(){
        return segites++;
    }

    public abstract int boldogsagErtek(int mutato);

    public int kor(){
        kor = AKTUALIS_EV-szuletesiEv;
        return kor;
    }


    public String getAzonosito() {
        return azonosito;
    }

    public void setAzonosito(String azonosito) {
        this.azonosito = azonosito;
    }

    public int getSzuletesiEv() {
        return szuletesiEv;
    }

    public void setSzuletesiEv(int szuletesiEv) {
        this.szuletesiEv = szuletesiEv;
    }

    public int getKor() {
        return kor;
    }

    public void setKor(int kor) {
        this.kor = kor;
    }

    public int getSegites() {
        return segites;
    }

    public void setSegites(int segites) {
        this.segites = segites;
    }

    public String getNem() {
        return nem;
    }

    public void setNem(String nem) {
        this.nem = nem;
    }

    public int getBoldogsagErtek() {
        return boldogsagErtek;
    }

    public void setBoldogsagErtek(int boldogsagErtek) {
        this.boldogsagErtek = boldogsagErtek;
    }
}
