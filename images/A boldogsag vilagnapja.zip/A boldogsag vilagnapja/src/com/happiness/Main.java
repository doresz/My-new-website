package com.happiness;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Main {
    private static int parkapcsolatiSzam;

    public static void main(String[] args){
        List<Ember> ember = new ArrayList<>();
        ember.add(new Férfi(1990));
        ember.add(new Férfi(1948));
        ember.add(new Férfi(1968));
        ember.add(new Férfi(1977));
        ember.add(new Holgy(1981, 2));
        ember.add(new Holgy(1993, 0));
        ember.add(new Holgy(1965, 4));
        ember.add(new Holgy(1950, 1));
        ember.add(new Holgy(1987, 1));

        for (Ember e : ember) {
            System.out.println(e);
        }

        for (int i = 0; i < ember.size(); i++) {
            parkapcsolatiSzam = (int) (Math.random() * 10) - 10;
            if (ember.get(i) instanceof Férfi) {
                ((Férfi) ember.get(i)).sikeres();
                //System.out.println(((Férfi) ember.get(i)).getSikeresseg());
            }
            ember.get(i).boldogsagErtek(parkapcsolatiSzam);

        }


        System.out.println("--------------------->");

        int randomEmber = (int) (Math.random() * ember.size());
        int randomEmber2 = (int) (Math.random() * ember.size());
        int randomUjszulottSzam = (int) (Math.random() * 3);
        System.out.println(ember.get(randomEmber));
        ember.get(randomEmber2).segites();
        //System.out.println("segites : "+ember.get(randomEmber2).getSegites());
        if (ember.get(randomEmber2) instanceof Holgy) {
            ((Holgy) ember.get(randomEmber2)).szul(randomUjszulottSzam);
            System.out.println((Holgy) ember.get(randomEmber2));
        }
        System.out.println("--------------------->");

        int sum = 0;
        double db = 0;

        for(Ember emb : ember){
            System.out.println(emb);
            sum+=emb.getBoldogsagErtek();
            db++;
        }

        double atlag = sum/db;
        System.out.println(atlag);

        ember.sort(new Comparator<Ember>() {
            @Override
            public int compare(Ember o1, Ember o2) {
                if(o1.getBoldogsagErtek()>o2.getBoldogsagErtek()){
                    return -1;
                }
                return 1;
            }
        });
        System.out.println("--------------------->");

        for(Ember e : ember){
            System.out.println(e);
        }



    }
}
