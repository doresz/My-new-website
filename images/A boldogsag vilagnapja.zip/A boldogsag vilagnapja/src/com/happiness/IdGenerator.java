package com.happiness;

public class IdGenerator {
    private static IdGenerator id = null;
    public static IdGenerator getInstance(){
        if(id == null){
            id = new IdGenerator();
        }
        return id;
    }
    private int nextAzonosito;
    public String getEgyediAzonosito(Ember ember){
        String kovetkezoAzonosito = null;
        nextAzonosito++;
        if(ember instanceof Holgy){
            kovetkezoAzonosito = "H"+nextAzonosito;
        }
        else if (ember instanceof Férfi)
            kovetkezoAzonosito = "F"+nextAzonosito;

        return kovetkezoAzonosito;
    }
}
