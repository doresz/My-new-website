import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Boszorkanyok b = new Boszorkanyok("Julia", magicValue());
        Boszorkanyok b2 = new Boszorkanyok("Melody", magicValue());
        Boszorkanyok b3 = new Boszorkanyok("Brunhilda", magicValue());
        Boszorkanyok b4 = new Boszorkanyok("Maria", magicValue());
        Tunderek t = new Tunderek("Sandra",magicValue());
        Tunderek t2 = new Tunderek("Sophie",magicValue());
        Tunderek t3 = new Tunderek("Hilda",magicValue());
        Tunderek t4 = new Tunderek("Dorothy", magicValue());

        List<Boszorkanyok> boszi = new ArrayList<>();
        List<Tunderek> tunde = new ArrayList<>();

        List<Holgyek> list = new ArrayList<>();
        list.add(b);
        list.add(b2);
        list.add(b3);
        list.add(b4);
        list.add(t);
        list.add(t2);
        list.add(t3);
        list.add(t4);

        for (Holgyek h : list) {
            System.out.println(h);
        }
        b.atok();
        b2.atok();
        b3.atok();
        b4.atok();
        t.aldas();
        t2.aldas();
        t3.aldas();
        t4.aldas();

        System.out.println("----------------->");

        List<Holgyek>listNew = new ArrayList<>();
        listNew.add(b);
        listNew.add(b2);
        listNew.add(b3);
        listNew.add(b4);
        listNew.add(t);
        listNew.add(t2);
        listNew.add(t3);
        listNew.add(t4);

        int sum = 0;
        double db = 0;
        for(int i = 0;i<listNew.size();i++){
            System.out.println(listNew.get(i));
            sum = sum + listNew.get(i).getMagicValue();
            db++;
        }

        System.out.println("----------------->");

        System.out.println("A varázserők átlaga: "+(sum/db));

        boszi.add(b);
        boszi.add(b2);
        boszi.add(b3);
        boszi.add(b4);

        System.out.println("----------------->");

        Collections.sort(boszi, new Comparator<Boszorkanyok>() {
            @Override
            public int compare(Boszorkanyok o1, Boszorkanyok o2) {
                if (o1.getMagicValue() > o2.getMagicValue()) {
                    return -1;
                }
                return 1;
            }
        });

        System.out.println("A leggonoszabb boszorkány(ok): ");

        boszi.sort(new Comparator<Boszorkanyok>() {
            @Override
            public int compare(Boszorkanyok o1, Boszorkanyok o2) {
                if (boszi.get(0).getMagicValue() == o1.getMagicValue()) {
                    System.out.println(o1);
                    return 0;
                } else if (boszi.get(0).getMagicValue() == o2.getMagicValue()) {
                    System.out.println(o2);
                    return 0;
                }

                return 1;
            }
        });

        System.out.println("----------------->");

        System.out.println("Boszik gonosz sorrendben csökkenően: ");
        for(int i =0;i<boszi.size();i++) {
            System.out.println(boszi.get(i));
        }

        tunde.add(t);
        tunde.add(t2);
        tunde.add(t3);
        tunde.add(t4);

        System.out.println("----------------->");

        System.out.println("A legjóságosabb tündér(ek): ");

        tunde.sort(new Comparator<Tunderek>() {
            @Override
            public int compare(Tunderek o1, Tunderek o2) {
                if (o1.getMagicValue() > o2.getMagicValue()) {
                    return -1;
                }
                return 1;
            }
        });

        tunde.sort(new Comparator<Tunderek>() {
            @Override
            public int compare(Tunderek o1, Tunderek o2) {
                if (tunde.get(0).getMagicValue() == o1.getMagicValue()) {
                    System.out.println(o1);
                    return 0;
                } else if (tunde.get(0).getMagicValue() == o2.getMagicValue()) {
                    System.out.println(o2);
                    return 0;
                }

                return 1;
            }
        });

        System.out.println("----------------->");

        System.out.println("Tündérek jóság szerint csökkenően: ");
        for(int i = 0;i<tunde.size();i++){
            System.out.println(tunde.get(i));
        }

    }

    public static int magicValue() {
        int a = (int) (Math.random() * 100) + 1;
        return a;
    }
}
