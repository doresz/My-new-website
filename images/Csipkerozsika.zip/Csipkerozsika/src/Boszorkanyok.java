public class Boszorkanyok extends Holgyek {
   private static final int MAGIC_SZORZO = -3;

    public Boszorkanyok(String name, int magicValue) {
        super(name, magicValue);
    }

    public String toString(){
        return "Boszorkány : "+super.getName()+" "+super.getMagicValue();
    }
}
