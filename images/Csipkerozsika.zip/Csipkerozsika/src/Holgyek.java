public abstract class Holgyek {
    private String name;
    private int magicValue;

    public Holgyek(String name, int magicValue) {
        this.name = name;
        this.magicValue = magicValue;
    }
    public void aldas(){
        magicValue++;
    }
    public void atok(){
        if(magicValue>0) {
            magicValue--;
        }
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getMagicValue() {
        return magicValue;
    }

    public void setMagicValue(int magicValue) {
        this.magicValue = magicValue;
    }
}
