public class Tunderek extends Holgyek {
    private static final int MAGIC_SZORZO = 3;

    public Tunderek(String name, int magicValue) {
        super(name, magicValue);
    }

    public String toString(){
        return "Tündérek : "+super.getName()+" "+super.getMagicValue();
    }

    }

