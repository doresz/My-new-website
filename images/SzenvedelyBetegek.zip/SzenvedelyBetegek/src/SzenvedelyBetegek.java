public class SzenvedelyBetegek {
    private String nev;
    private int TajSzam;

    public SzenvedelyBetegek(){

    }

    public SzenvedelyBetegek(String nev,int TAJ){
        this.nev = nev;
        this.TajSzam = TAJ;
    }

    @Override
    public String toString() {
        return "SzenvedelyBetegek{" +
                "nev = '" + nev + '\'' +
                ", TajSzam = " + TajSzam +
                '}';
    }

    public String getNev() {
        return nev;
    }

    public void setNev(String nev) {
        this.nev = nev;
    }

    public int getTajSzam() {
        return TajSzam;
    }

    public void setTajSzam(int tajSzam) {
        TajSzam = tajSzam;
    }
}
