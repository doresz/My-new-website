public class FacebookFuggok extends SzenvedelyBetegek {
    private int belepes;
    private static final int BELEPES_HATAR = 10;

    public FacebookFuggok(){

    }

    public FacebookFuggok(String nev, int TAJ) {
        super(nev, TAJ);
    }
    public String toString() {
        return "Facebookfüggők : nev = " + super.getNev() + " TAJ szám = " + super.getTajSzam() + " függő? = " + fuggo();
    }

    public int internetezik() {
        return belepes++;

    }

    public boolean fuggo() {
        if(belepes > BELEPES_HATAR) {

            return true;
        }
        else{

        }
        return false;
    }

    public int getBelepes() {
        return belepes;
    }

    public void setBelepes(int belepes) {
        this.belepes = belepes;
    }

    public static int getBelepesHatar() {
        return BELEPES_HATAR;
    }
}
