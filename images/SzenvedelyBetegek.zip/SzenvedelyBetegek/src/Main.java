import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[]args){
        List<SzenvedelyBetegek> szenvedely = new ArrayList<>();
        Alkoholfuggok alkohol = new Alkoholfuggok();
        FacebookFuggok facebook = new FacebookFuggok();
        SzenvedelyBetegek[]sze = {alkohol,facebook};
        int randomAlkohol = (int)(Math.random()*20)+1;
        int[]iszikInternetezik = {alkohol.iszik(randomAlkohol),facebook.internetezik()};
        int random = (int)(Math.random()*iszikInternetezik.length);
        FileReader reader = null;
        try {
            reader = new FileReader("C:\\Users\\HP\\Desktop\\Java feladatsor\\paciensek.txt");
            Scanner first = new Scanner(reader);
            while(first.hasNext()){
                String[]paciens = first.nextLine().split(";");
                int random2 = (int)(Math.random()*sze.length);
                if(sze[random2]==alkohol) {
                    szenvedely.add(new Alkoholfuggok(paciens[0], Integer.parseInt(paciens[1])));
                }
                else if(sze[random2]==facebook){
                    szenvedely.add(new FacebookFuggok(paciens[0], Integer.parseInt(paciens[1])));
                }

            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        for(SzenvedelyBetegek sz : szenvedely){
            if(iszikInternetezik[random]==iszikInternetezik[0]){
                alkohol.iszik(randomAlkohol);
            }
            else if(iszikInternetezik[random]==iszikInternetezik[1]){
                facebook.internetezik();
            }
            System.out.println(sz);
        }


    }


    }

