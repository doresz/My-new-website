public class Alkoholfuggok extends SzenvedelyBetegek {
    private boolean visszaEso;
    private int alkoholSzint;
    private static final int HATAR1 =30;
    private static final int HATAR2 = 20;

    public Alkoholfuggok(){

    }
    public Alkoholfuggok(String nev, int TAJ) {
        super(nev, TAJ);
    }
    public String toString(){
        return "Alkoholfüggők : nev = "+super.getNev()+" TAJ szám = "+super.getTajSzam()+" függő? = "+fuggo();
    }

    public int iszik(int alkoholMennyiseg) {
        alkoholSzint = alkoholSzint+alkoholMennyiseg;
        return alkoholSzint;
    }

    public void internetezik() {

    }

    public boolean fuggo() {
        if(alkoholSzint>HATAR1){
            visszaEso = false;

        }
        else if(alkoholSzint>HATAR2){
            visszaEso = true;

        }
        return false;
    }

    public boolean isVisszaEso() {
        return visszaEso;
    }

    public void setVisszaEso(boolean visszaEso) {
        this.visszaEso = visszaEso;
    }

    public int getAlkoholSzint() {
        return alkoholSzint;
    }

    public void setAlkoholSzint(int alkoholSzint) {
        this.alkoholSzint = alkoholSzint;
    }

    public static int getHATAR1() {
        return HATAR1;
    }

    public static int getHATAR2() {
        return HATAR2;
    }
}
