package com.stars;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        List<Sztarok> sztar = new ArrayList<>();
        List<MuvesziSztarok> muvesz = new ArrayList<>();
        List<rtlKlubSztarok> rtl = new ArrayList<>();
        try {
            FileReader reader = new FileReader("C:\\Users\\HP\\Desktop\\Java feladatsor\\sztarok.txt");
            Scanner first = new Scanner(reader);
            while (first.hasNext()) {
                String file = first.nextLine();
                int a = (int) (Math.random() * 50) + 70;
                String[]muveszetiAgak = {"hegedűművész","zongorista","festő","író"};
                int randomMuvAg = (int)(Math.random()*muveszetiAgak.length);
                if (a > 95) {
                    muvesz.add(new MuvesziSztarok(file, a,muveszetiAgak[randomMuvAg]));
                } else if (a < 75) {
                    rtl.add(new rtlKlubSztarok(file, a));
                } else {
                    System.out.println("Sikertelen válogatás");
                }
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        for (MuvesziSztarok e : muvesz) {
            e.fizetesMuv();
            sztar.add(e);
            System.out.println(e);
        }
        for (rtlKlubSztarok e : rtl) {
            e.fizetesRtl();
            sztar.add(e);
            System.out.println(e);
        }


        System.out.println("------------------>");
        System.out.println("Az alábbi sztárokról jelent meg cikk : ");

        int muveszekSzama = 0;
        int rtlSzama = 0;

        for (int i = 0; i < 10; i++) {
            sajtofigyelo(sztar);

    }
        for(Sztarok e : sztar){
            if(e.getIQ()>95){
                muveszekSzama++;
            }
            else if(e.getIQ()<75){
                rtlSzama++;
            }
        }

        System.out.println("------------------>");
        System.out.println("A művészekről megjelent cikkek száma = "+muveszekSzama);
        System.out.println("------------------>");
        System.out.println("Az rtl sztárokról megjelent cikkek száma = "+rtlSzama);

        sztar.sort(new Comparator<Sztarok>() {
            @Override
            public int compare(Sztarok o1, Sztarok o2) {
                if (o1.getHanyszorIr() > o2.getHanyszorIr()) {
                    return -1;
                }
                return 0;
            }
        });
        System.out.println("------------------>");

        muvesz.sort(new Comparator<MuvesziSztarok>() {
            @Override
            public int compare(MuvesziSztarok o1, MuvesziSztarok o2) {
                if (o1.getHanyszorIr() > o2.getHanyszorIr()) {
                    return -1;
                }
                return 0;
            }
        });
        rtl.sort(new Comparator<rtlKlubSztarok>() {
            @Override
            public int compare(rtlKlubSztarok o1, rtlKlubSztarok o2) {
                if (o1.getHanyszorIr() > o2.getHanyszorIr()) {
                    return -1;
                }
                return 0;
            }
        });

    }


    public static void sajtofigyelo(List<Sztarok> sztar) {
        int randomCikk = (int) (Math.random() * sztar.size());
        sztar.get(randomCikk).megjelenik();
        System.out.println(sztar.get(randomCikk));
    }


}

