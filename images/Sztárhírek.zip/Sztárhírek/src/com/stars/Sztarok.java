package com.stars;

public class Sztarok {
    private String name;
    private int IQ;
    private int hanyszorIr;
    private double fizetes;
    private static final int ALAP_GAZSI = 100000;
    private static final int Y  = 1000;
    private static final int SZORZO = 20;

    public Sztarok(){

    }

    public Sztarok(String name,int IQ){
        this.name = name;
        this.IQ = IQ;
    }

    public int megjelenik(){
        return hanyszorIr++;
    }

    @Override
    public String toString() {
        return "Sztarok{" +
                "name='" + name + '\'' +
                ", IQ=" + IQ +
                ", hanyszorIr=" + hanyszorIr + " fizetés = "+fizetes+
                '}';
    }
    public double fizetesMuv(){
            fizetes = ALAP_GAZSI+(IQ*SZORZO);
        return fizetes;
    }
    public double fizetesRtl(){
        double r = 1/(double)IQ;
        fizetes = ALAP_GAZSI+(r*Y);
        return fizetes;
    }

    public String getName() {
        return name;
    }

    public int getIQ() {
        return IQ;
    }

    public int getHanyszorIr() {
        return hanyszorIr;
    }

    public int getALAP_GAZSI() {
        return ALAP_GAZSI;
    }

    public int getSZORZO() {
        return SZORZO;
    }

    public double getFizetes() {
        return fizetes;
    }
}
