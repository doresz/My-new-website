package com.stars;

public class rtlKlubSztarok extends Sztarok {
    public rtlKlubSztarok(){

    }
    public rtlKlubSztarok(String name,int IQ) {
        super(name,IQ);
    }
    public String toString(){
        return "RTL KLub Sztárok name = "+super.getName()+" IQ = "+super.getIQ()+" fizetés = "+super.getFizetes();
    }


}
