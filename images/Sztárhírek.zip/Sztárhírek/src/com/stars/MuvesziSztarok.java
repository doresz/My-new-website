package com.stars;

public class MuvesziSztarok extends Sztarok {
    String muveszetiAg;

    public MuvesziSztarok(){

    }

    public MuvesziSztarok(String name,int IQ,String muveszetiAg) {
        super(name,IQ);
        this.muveszetiAg = muveszetiAg;

    }

    @Override
    public String toString() {
        return "MuvesziSztarok{" + "name = "+super.getName()+" IQ = "+super.getIQ()+
                " muveszetiAg='" + muveszetiAg + '\'' + " fizetés = "+super.getFizetes()+
                '}';
    }

    public String getMuveszetiAg() {
        return muveszetiAg;
    }

    public void setMuveszetiAg(String muveszetiAg) {
        this.muveszetiAg = muveszetiAg;
    }

}
