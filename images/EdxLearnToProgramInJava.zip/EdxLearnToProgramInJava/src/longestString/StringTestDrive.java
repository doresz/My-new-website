package longestString;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StringTestDrive {

    public static void main(String[]args){
        Scanner input = new Scanner(System.in);
        StringOsztaly osztaly = new StringOsztaly();
        osztaly.longestName(input,3);


    }
}
