package longestString;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class StringOsztaly {
    public String name;
    public int StringLength;

    public StringOsztaly(){

    }

    public StringOsztaly(String name,int StringLength){
        this.name = name;
        this.StringLength = StringLength;
    }

    @Override
    public String toString() {
        return "StringOsztaly{" +
                "name='" + name + '\'' +
                ", StringLength=" + StringLength +
                '}';
    }
    public void longestName(Scanner input, int j) {
        input = new Scanner(System.in);
        String longWord = " ";
        List<StringOsztaly> list = new ArrayList<>();
        for (int i = 0; i < j; i++) {
            System.out.println("Write the name!");
            String name = input.nextLine();
            list.add(new StringOsztaly(name, name.length()));

        }
        list.sort(new Comparator<StringOsztaly>() {
            @Override
            public int compare(StringOsztaly o1, StringOsztaly o2) {
                if (o1.getStringLength() > o2.getStringLength()) {
                    return 1;

                }
                return -1;
            }

        });
        System.out.println("The longest String is : "+list.get(list.size()-1).getName());


    }


        public String getName() {
        return name;
    }

    public int getStringLength() {
        return StringLength;
    }
}
