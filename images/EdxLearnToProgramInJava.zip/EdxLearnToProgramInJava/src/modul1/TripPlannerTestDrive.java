package modul1;

import java.util.Scanner;

public class TripPlannerTestDrive {
    public static void main(String[] args) {
        intro();
        budget();
        time();
        distance();

    }

    public static void intro() {
        System.out.println("Welcome to a Vacation Planner!");
        Scanner first = new Scanner(System.in);
        System.out.print("What is your name?");
        String name = first.nextLine();

        Scanner second = new Scanner(System.in);
        System.out.print("Nice to meet you" + " " + name + " ,where are you travelling?");
        String location = second.nextLine();

        System.out.println("Great!" + " " + location + " sounds like a great trip!");
    }

    public static void budget() {
        Scanner third = new Scanner(System.in);
        System.out.print("How many days are you going to spend travelling?");
        int days = third.nextInt();

        Scanner fourth = new Scanner(System.in);
        System.out.print("How much money, in USD are you planning to spend on your trip?" + " ");
        int money = fourth.nextInt();

        Scanner fifth = new Scanner(System.in);
        System.out.print("What is the three letter currency symbol for your travel destination?");
        String symbol = fifth.nextLine();

        Scanner sixth = new Scanner(System.in);
        System.out.print("How many" + " " + symbol + " are there in 1 USD?");
        double symboliInUSD = sixth.nextDouble();

        int hours = days * 60;
        int minutes = hours * 60;
        double moneySpend = (double) money / days * 100;
        double m = (int) moneySpend;
        double mSpend = m / 100.0;

        double symbolSpend = (money * symboliInUSD) * 100;
        double s = (int) symbolSpend;
        double sS = s / 100.0;

        double symbolSpendPerDay = (money * symboliInUSD / days) * 100;
        double sy = (int) symbolSpendPerDay;
        double sym = sy / 100.0;
        System.out.println("If you are travelling for" + " " + days + " days that is the same as" + " " + hours + " hours or" + " " + minutes + " minutes.");
        System.out.println("If you are going to spend" + " " + money + " USD that means per day you can spend up to " + mSpend + " USD");
        System.out.println("Your total budget in" + " " + symbol + " is" + " " + sS + " which per day is" + " " + sym + " " + symbol);
    }

    public static void time() {
        Scanner seventh = new Scanner(System.in);
        System.out.print("What is the difference, in hours, between your home and your destination?");
        int timeDifference = seventh.nextInt();

        int midnight = 24;
        int noon = 12;
        int midPlus = timeDifference+midnight;
        int noonPlus = timeDifference+noon;

       int m = midPlus%midnight;
       int n = noonPlus%noon;

        System.out.println("That means that when it is midnight at home it will be" + " " + m + ":00" + " in your travel destination and when it is noon at home it will be " + n + ":00");
    }

    public static void distance() {
        Scanner eight = new Scanner(System.in);
        System.out.print("What is the square area of your destination country in km?");
        double squareArea = eight.nextDouble();

        double km = Math.sqrt(squareArea);
        double miles = km / 1.60934;
        double miles2 = (miles * miles) * 100;
        double mi = (int) miles2;
        double mi2 = mi / 100.0;

        System.out.println("In miles2 that is" + " " + mi2);
       
    }
}
