import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Proba {
    public static void main(String[] args) {
        int result = 0;
        for (int i = 0; i < 5; i++) {
            if (i == 3) {
                result += 10;
            } else {
                result += i;
            }
        }
        System.out.println(result);

        Scanner first = new Scanner(System.in);
        System.out.println("Write a number!");
        int a = first.nextInt();
        if (a % 2 != 0) {
            System.out.println("This is an odd number!");
        } else {
            System.out.println("This is an even number!");
        }
        for (int i = 1; i < 8; i++) {
            for (int j = 1; j < i; j++) {
                System.out.print(i);
            }
            System.out.println();
        }

        Scanner input = new Scanner(System.in);
        longestName(input, 3);


        for (int i = 1; i < 5; i++) {
            System.out.println("2 times " + i + " = " + 2 * i);
        }

        int c = daysInMonth(2);
        System.out.println(c);

        int i = 1;
        int j = 1;
        int k = 1;

        while (i <= 2) {
            while (j <= 3) {
                while (k <= 4) {
                    System.out.print("*");
                    k++;
                }
                System.out.print("!");
                j++;

            }
            i++;
            System.out.println();
        }
        System.out.println();

        System.out.println("----------->");

        for (int i2 = 1; i2 <= 2; i2++) {
            for (int j2 = 1; j2 <= 3; j2++) {
                for (int k2 = 1; k2 <= 4; k2++) {
                    System.out.print("*");
                }
                System.out.print("!");
            }
            System.out.println();
        }
        System.out.println();


    }

    public static int daysInMonth(int month) {
        int days = 0;
        switch (month) {
            case 1:
                days = 31;
                break;
            case 2:
                days = 29;
                break;
            case 3:
                days = 31;
                break;
            case 4:
                days = 30;
                break;
            case 5:
                days = 31;
                break;
            case 6:
                days = 30;
                break;
            case 7:
                days = 31;
                break;
            case 8:
                days = 31;
                break;
            case 9:
                days = 30;
                break;
            case 10:
                days = 31;
                break;
            case 11:
                days = 30;
                break;
            case 12:
                days = 31;
                break;

        }
        return days;

    }

    public static void longestName(Scanner input, int j) {
        input = new Scanner(System.in);
        String longWord = " ";
        String[] name = {};
        List<String> list = new ArrayList<>();
        for (int i = 0; i < j; i++) {
            System.out.println("Write the name!");
            name = input.nextLine().split("");

        }
        int k = 0;
        int l = 0;
        for (k = 0; k < name.length; k++) {
            for (l = k + 1; l < name.length; l++) {
                if (name[k].length() > name[l].length()) {
                    longWord = name[k];
                }
            }

        }


        System.out.println(longWord);

    }

}







