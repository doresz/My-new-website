package modul4;

import java.util.Scanner;

public class MazeRunner {
	public static Maze maze = new Maze();
    public static void main(String[] args) {
        int moves = 0;
        intro();
        maze.printMap();
        while(!maze.didIWin()||moves!=100) {
            userMove();//Scanner input, where does the user move?
            moves++;
            movesMessage(moves);// how many moves does the user have?
            if (moves == 100) {
                System.out.println("Sorry, but you didn't escape in time- you lose!");
            }
            else if(maze.didIWin()) {
            	System.out.println("Congratulations, you made it out alive,and you did it in " + moves + " moves!");  
            	
            }
            	
    }
    }
        

    public static void intro() {
        System.out.println("Welcome to Maze Runner!");
        System.out.println("Here is your current position: ");

    }

    public static String userMove() {
        String direction = "";
        Scanner input = new Scanner(System.in);
        System.out.println("Where would you like to move(R,L,U,D)?");
        direction = input.nextLine();
        if(maze.isThereAPit(direction)) {
            navigatePit(direction,input);
          
        } 
        else if(!maze.isThereAPit(direction)) {
        if (direction.equals("R")&&maze.canIMoveRight()) {
            maze.moveRight();
        } else if (direction.equals("L")&&maze.canIMoveLeft()) {
            maze.moveLeft();

        } else if (direction.equals("U")&&maze.canIMoveUp()) {
            maze.moveUp();

        } else if (direction.equals("D")&&maze.canIMoveDown()) {
            maze.moveDown();

        } 
        else {
        	System.out.println("Sorry, you've hit a wall!");
        }
        
        maze.printMap();
        
        }
        
       
        return direction;
    }

    public static void movesMessage(int moves) {
        if (moves == 50) {
            System.out.println("Warning: You have made 50 moves, you have 50 remaining before the maze exit closes");
        } else if (moves == 75) {
            System.out.println("\tAlert! You have made 75 moves, you only have 25 moves left to escape.");
        } else if (moves == 90) {
            System.out.println("DANGER! You have made 90 moves, you only have 10 moves left to escape!!");
        } else if (moves == 100) {
            System.out.println("Oh no! You took too long to escape, and now the maze exit is closed FOREVER >:[");
        }
    }

    public static void navigatePit(String direction,Scanner input2) {
        Scanner input = new Scanner(System.in);
            System.out.println("Watch out! There's a pit ahead, jump it?");
            String a = input.nextLine();
            if(!a.startsWith("y")) {
            	userMove();
            	   
            }
            else {
            maze.jumpOverPit(direction);
            maze.printMap();
            
            } 

        }


    }




