package modul3;

public class Crypto {
    public static void main(String[] args) {
        String text = normalizeText("This is some \"really\" great. (Text)!?");
        System.out.println(text);
        String b = obify(text);
        System.out.println(b);
        String c = caeserify(b, -2);
        System.out.println(c + " " + b);
        String d = shiftAlphabet(-2);
        System.out.println(d);
        String e = groupify(text, 7);
        System.out.println(e);
        System.out.println("--------------->");
        String encrypted = encryptString(text, 3, 7);
        System.out.println(encrypted);
        String ungruopif = ungroupify(e);
        System.out.println("The ungroupified String: "+ungruopif);
        String decrypt = decryptString(encrypted,3);
        System.out.println("The \"decrypted\" normalized input String: "+decrypt);

    }

    public static String normalizeText(String a) {
        String b = a.replaceAll(" ", "");
        String c = b.replace("\"", "");
        String d = c.replace(".", "");
        String e = d.replace("(", "");
        String f = e.replace(")", "");
        String g = f.replace("!", "");
        String h = g.replace("?", "");
        String i = h.toUpperCase();

        return i;
    }

    public static String obify(String s) {
            StringBuffer result = new StringBuffer("");
            StringBuffer b = new StringBuffer(s);
            for(int i = 0; i < b.length(); i++) {
                String substring = b.substring(i, i+1);
                if(isConsanantCharacter(substring)) {
                    result.append("OBy" + substring);
                } else {
                    result.append(substring);
                }
            }
            return result.toString();
        }

        public static boolean isConsanantCharacter(String character){
            String vowel = "AEIOU";
            return vowel.contains(character);
        }


    public static String caeserify(String a, int shift) {
        String result = "";
        int start = 0;
        int ascii = 0; //
        for (int i = 0; i < a.length(); i++) {
            ascii = (int) a.charAt(i) + shift;//"String a" karaktereinek ASCII kódja a változtatással
            if (ascii <= 90 && ascii >= 65 || ascii <= 122 && ascii >= 97) {
                result = result + (char) ascii;
            } else if (ascii >= 90 || ascii >= 122) {
                ascii = ascii - 26;
                result = result + (char) ascii;
            } else if (ascii <= 65 || ascii <= 97) {
                ascii = ascii + 26;
                result = result + (char) ascii;
            }

        }

        return result;

    }

    public static String shiftAlphabet(int shift) {
        int start = 0;
        if (shift < 0) {
            start = (int) 'Z' + shift + 1;
        } else {
            start = 'A' + shift;
        }
        String result = "";
        char currChar = (char) start;
        for (; currChar <= 'Z'; ++currChar) {
            result = result + currChar;
        }
        if (result.length() < 26) {
            for (currChar = 'A'; result.length() < 26; ++currChar) {
                result = result + currChar;
            }
        }
        return result;
    }

    public static String groupify(String a, int b) {
        String d = "";
        String e = "";
        StringBuilder str = new StringBuilder(a);
        for(int i = 0;i<str.length();i = i+b+1){
            d = str.insert(i," ").toString();
        }
        if (a.length() % b!=0) {
            e = d.concat("x");
            return e;
        }

        return d;//kijavítani! + 'x' a végére ha nem jön ki pontosan!
    }

    public static String encryptString(String text, int shiftValue, int codeGroupSize) {
        StringBuilder str = new StringBuilder(text);
        for(int i = 0;i<str.length();i = i+codeGroupSize+1){
            str.insert(i," ");
        }
        text = normalizeText("This is some \"really\" great. (Text)!?");
        System.out.println("The normalized String : " + text);
        String b = obify(text);
        System.out.println("The obfuscated String : " + b);
        String c = caeserify(b, shiftValue);
        System.out.println("The caeserifyed String is : " + c);
        String d = groupify(c, codeGroupSize);
        System.out.print("The encrypted String is : ");

        return d;
    }


    public static String ungroupify(String a) {
        String b = "";
        String c = "";
        for(int i = 0;i<a.length();i++){
            b = a.replaceAll(" ","");
            c = b.replace("x","");

        }

        return c;
    }

    public static String decryptString(String encrypted, int shiftValue) {
        String replaced = "";
        String replaced2 = "";
        for(int i = 0;i<encrypted.length();i++){
            replaced = encrypted.replaceAll(" ","");
            replaced2 = replaced.replace("x","");

        }

        String result = "";
        String result2 = "";


        int start = 0;
        int ascii = 0; //
        for (int i = 0; i < replaced2.length(); i++) {
            ascii = (int) replaced2.charAt(i) -shiftValue;//"String a" karaktereinek ASCII kódja a változtatással
            if (ascii <= 90 && ascii >= 65 || ascii <= 122 && ascii >= 97) {
                result = result + (char) ascii;
            } else if (ascii >= 90 ||ascii>=122 ) {
                ascii = ascii +26;
                result = result + (char) ascii;
            }
            else if(ascii<=65||ascii<=97){
                ascii = ascii+26;
                result = result +(char)ascii;

            }

        }
        result2 = result.replaceAll("OBy","");

        return result2;
    }
}
