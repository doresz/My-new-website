package modul2;

import java.util.Random;
import java.util.Scanner;

public class OddsAndEvens {
    public static void main(String[]args){
        System.out.println("Let's play a game called \"Odds\" and \"Evens\"!");
        Scanner input = new Scanner(System.in);
        System.out.print("What's your name?");
        String name = input.nextLine();

        Scanner second = new Scanner(System.in);
        System.out.print("Hi "+name+" Which do you choose? (O)dds or (E)vens? ");
        String oddsOrEvens = second.nextLine();

        System.out.println("--------------------------------");

        Scanner third = new Scanner(System.in);
        System.out.print("How many \"fingers\" do you put out?");
        int fingers = third.nextInt();

        Random rand = new Random();
        int computer = rand.nextInt(6);

        System.out.println("The computer plays number "+ computer+" \"fingers\".");

        System.out.println("--------------------------------");

        int sum = fingers+computer;

        if(oddsOrEvens.equals("O")){
            System.out.println(name+" has picked odds. The computer will be evens.");
            System.out.println(fingers+"+"+computer + "="+sum);
            if(sum%2!=0){
                System.out.println("That means "+name+" wins!");
            }
            else{
                System.out.println("The computer wins!");
            }
        }
        else if(oddsOrEvens.equals("E")){
            System.out.println(name+" has picked evens. The computer will be odds.");
            System.out.println(fingers+"+"+computer + "="+sum);
            if(sum%2==0){
                System.out.println("That means "+name+" wins!");
            }
            else{
                System.out.println("The computer wins!");
            }
        }
        System.out.println("--------------------------------");

    }
}
